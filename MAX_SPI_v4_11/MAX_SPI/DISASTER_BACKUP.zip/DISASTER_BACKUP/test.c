#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define BUFFER_SIZE 1024

long getLength(char *fileName){
  FILE *f = fopen(fileName, "rb");
  fseek(f, 0, SEEK_END);
  long fsize = ftell(f);
  fseek(f, 0, SEEK_SET);
  return fsize;
}
void getContent(char *fileName,char buffer[]){
  long fsize = getLength(fileName);
  FILE *f = fopen(fileName, "rb");
  char *string = malloc(fsize + 1);
  buffer = malloc(fsize+1);
  fread(string, fsize, 1, f);
  fclose(f);
  string[fsize] = 0;
  //printf("%s\n",string);
  for(int i = 0; i < fsize; i++)
    buffer[i] = string[i];
  free(string);
  return;
}


int main(int argc, char ** argv){
  printf("Starting Service...\nUsing Arguments:\n");
  for(int i = 0; i < argc; i++){
    printf("Arg:(%d): %s\n",i,argv[i]);
  }

  long fsize = getLength(argv[1]);
  FILE *f = fopen(fileName, "rb");
  char *string = malloc(fsize + 1);
  fread(string, fsize, 1, f);
  fclose(f);
  string[fsize] = 0;
  printf("%s\n",string);
  //printf("%s",string);
  //START OF PARSING
  //char *method = malloc(8);
  //strncpy(method, string,4);
  //int i;
  /*for(i = 0; i <=7; i++){
	  //printf("%s\n",method);
	  method[i] = string[i];
  }*/
  //method[i+1] = 0;
  
  //END OF PARSING
  free(string);
  return 0;
}
