//#include <mysql/mysql.h>d
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/socket.h>
#include <linux/in.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
/* limits.h defines "PATH_MAX". */
#include <limits.h>
#include <stdbool.h>
#include <fcntl.h>
#include <sys/wait.h>
#define BUFFER_SIZE 8192
#include <signal.h>


unsigned long hash(unsigned char *str){
    unsigned long hash = 5381;
    int c;

    while (c = *str++)
        hash = ((hash << 5) + hash) + c; /* hash * 33 + c */

    return hash;
}


/* Catch Signal Handler functio */
void signal_callback_handler(int signum){

        printf("Caught signal SIGPIPE %d\n",signum);
}

void signal_term(int signo);
void signal_int(int signo);
void signal_kill(int signo);
void signal_hup(int signo);
void signal_other(int signo);

///* Catch Signal Handler SIGPIPE */
//signal(SIGPIPE, signal_callback_handler);


char HOME[PATH_MAX] = ""; // = "/home/user/backbone/www";
char CERTPATH[PATH_MAX] = "fullchain.pem";
char  KEYPATH[PATH_MAX] = "privkey.pem";
//#define LOG_FILE_PATH "/root/log.txt"
char LOG_FILE_PATH[PATH_MAX] = ""; //"/home/user/backbone/log.txt";
//MYSQL *conn;

// FIFO file path
//char * myfifo = "/tmp/httpsd";

int getConfig(){
    FILE *fp;
    fp = fopen("/home/itamar/prod/config.txt", "r");
  
    /*File open operation failed.*/
    if (fp == NULL) return -1;

    int indent = 0;
    char arr[4][2][PATH_MAX];
    for(int i = 0; i < 4; i++){
      fscanf(fp, "%s", &arr[i][0] [0]);
      fscanf(fp, "%s", &arr[i][1] [0]);
//      printf("%s", arr[i][0]);
      if(strcmp("HOME",arr[i][0]) == 0)
	strcpy(HOME, arr[i][1]);
      if(strcmp("CERTPATH",arr[i][0]) == 0)
        strcpy(CERTPATH, arr[i][1]);
       if(strcmp("KEYPATH",arr[i][0]) == 0)
        strcpy(KEYPATH, arr[i][1]);
      if(strcmp("LOG_FILE_PATH",arr[i][0]) == 0)
        strcpy(LOG_FILE_PATH, arr[i][1]);
      printf("%s: %s\n", arr[i][0], arr[i][1]);
    }

    fclose(fp);
    return 0;
}
//
char mimes[50][2][256] = { {"html","text/html"},
 {"htm","text/html"},
 {"css","text/css"},
 {"js" ,"text/javascript"},
 {"gif" ,"image/gif"},
 {"jpg" ,"image/jpeg"},
 {"jpeg" ,"image/jpeg"},
 {"png" ,"image/png"},
 {"tiff" ,"image/tiff"},
 {"ico" ,"image/x-icon"},
 {"svg" ,"image/svg+xml"},
 {"csv" ,"text/csv"},
 {"txt" ,"text/plain"},
 {"xml" ,"text/xml"},
 {"mpeg" ,"audio/mpeg"},
 {"mp4" ,"video/mp4"},
 {"pdf" ,"application/pdf"},
 };



//--------- SSL FUNCTIONS ---------------------
struct Folder {
  long size;
  char **arr;
  char **type;
};
typedef struct
{
	int sock;
	struct sockaddr address;
	int addr_len;
} connection_t;


SSL_CTX *ctx;
void logger(char *){
	
}
int create_socket(int port)
{
    int s;
    struct sockaddr_in addr;

    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    //inet_addr("82.80.232.19");
    //htonl(INADDR_ANY);

    s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) {
        ////logger("Unable to create socket",true);
        //perror("Unable to create socket");
        exit(EXIT_FAILURE);
    }


    int reuse = 1;
    if (setsockopt(s, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, (const char*)&reuse, sizeof(reuse)) < 0)
        //logger("INFO: setting sockopt SO_REUSEADR failed", true);
//perror("setsockopt(SO_REUSEADDR) failed");
//    if (setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &(int){1}, sizeof(int)) < 0)
        perror("setsockopt(SO_REUSEADDR) failed");


    if (bind(s, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("Unable to bind");
        //logger("Unable to bind: will now exit with status EXIT_FAILURE", true);
        exit(EXIT_FAILURE);
    }

    if (listen(s, 1000000) < 0) {
        //logger("FATAL: Listen Error. Will now exit",true);
        perror("Unable to listen");
        exit(EXIT_FAILURE);
    }

    return s;
}

SSL_CTX *create_context()
{
    const SSL_METHOD *method;
    SSL_CTX *ctx;

    method = TLS_server_method();
	//SSLv23_server_method();
	//TLS_server_method();

    ctx = SSL_CTX_new(method);
    if (!ctx) {
        //logger("ALERT: Unable to create SSL Context, will now exit with status EXIT_FAILURE", true);
        //perror("Unable to create SSL context");
        ERR_print_errors_fp(stderr);
        exit(EXIT_FAILURE);
    }
    SSL_CTX_set_min_proto_version(ctx, TLS1_1_VERSION);
   // SSL_CTX_set_options(ctx, SSL_OP_NO_SSLv2 | SSL_OP_NO_SSLv3);
    //SSL_CTX_set_cipher_list(ctx, "TLSv1.2:TLSv1:SSLv3:!SSLv2:HIGH:!MEDIUM:!LOW");
    return ctx;
}

void configure_context(SSL_CTX *ctx)
{
    /* Set the key and cert */
       if (SSL_CTX_use_certificate_chain_file(ctx, CERTPATH) <= 0 ){ 
//, SSL_FILETYPE_PEM) <= 0) {
        //logger("Cannot set fullchain cert @",true);
        //logger(CERTPATH, true);
        //logger("Will now exit with status EXIT_FAILURE", true);
   // if (SSL_CTX_use_certificate_file(ctx, "cert.pem", SSL_FILETYPE_PEM) <= 0) {
        ERR_print_errors_fp(stderr);
        exit(EXIT_FAILURE);
    }

    if (SSL_CTX_use_PrivateKey_file(ctx, KEYPATH, SSL_FILETYPE_PEM) <= 0 ) {
        //logger("Cannot set private key @",true);
        //logger(KEYPATH,true);
        //logger("Will now exit with status EXIT_FAILURE",true);
        ERR_print_errors_fp(stderr);
        exit(EXIT_FAILURE);
    }
}
//====== END OF SSL FUNCTIONS================

//-------THREADS-----------------------------

	void * process(void * ptr){
	int len;
	connection_t * conn;
	printf("test\n");
	if (!ptr){
	 //logger("INFO: Thread did not pass pointer. Exiting Thread. ",true);
	 pthread_exit(0);
	 return 0;
	}
 
	conn = (connection_t *)ptr;
    SSL *ssl;
    ssl = SSL_new(ctx);
    SSL_set_fd(ssl, conn->sock);
    int sslSock = SSL_accept(ssl);
	//===========-----accept--------=================--------
     if(sslSock <= 0){
		SSL_shutdown(ssl);
		close(conn->sock);
		SSL_free(ssl);
        pthread_exit(0);
        return 0;
    } else {
	 long addr = (long)((struct sockaddr_in *)&conn->address)->sin_addr.s_addr;
	/*char address_str[64];
	sprintf(address_str, "%d.%d.%d.%d", 
		(int)((addr      ) & 0xff),
		(int)((addr >>  8) & 0xff),
		(int)((addr >> 16) & 0xff),
		(int)((addr >> 24) & 0xff));*/
	char *request = malloc(1024 * sizeof(char));
	memset(request, '\0', BUFFER_SIZE+1);
	int leng = SSL_read(ssl, request, BUFFER_SIZE*sizeof(char) );
	printf("|%s",request);
    SSL_write(ssl, "HTTP/1.1 200 OK\r\n\r\nHello", strlen("HTTP/1.1 200 OK\r\n\r\nHello"));

	SSL_shutdown(ssl);
	close(conn->sock);
	SSL_free(ssl);
	free(conn);
	////logger("FATAL: Thread will now drop, reason: unkown",true);
	pthread_exit(0);
	return 0;
	}
}
//====== END OF THREADS================

//------ START OF FOLDERS--------------

//======== END OF FOLDERS===============


void * keepalive(){

while(1){	
int error = 0;
socklen_t len = sizeof (error);
int sock = -1;
int retval = getsockopt (sock, SOL_SOCKET, SO_ERROR, &error, &len);
//To test if the socket is up:

if (retval != 0) {
    /* there was a problem getting the error code */
    fprintf(stderr, "error getting socket error code: %s\n", strerror(retval));
   // return 0;
}

if (error != 0) {
    /* socket has a non zero error status */
    fprintf(stderr, "socket error: %s\n", strerror(error));
}
}
 return 0;
}
//========== MAIN ==============
int main(int argc, char ** argv)
{
    printf("Setting up HTTPS Server\n");
		
    int sock = create_socket(443);
//    sock = create_socket(80);

    /* Handle connections */
    
	/*
    pthread_t thread_input;
    pthread_create(&thread_input, 0, interpreter, NULL);
    pthread_detach(thread_input);
   
   
    pthread_t thread_keepAlive;
    pthread_create(&thread_keepAlive, 0, (void *)keepalive, &sock);
	*/
   
	do
	{
		ctx = create_context();
		configure_context(ctx);
//    		printf("waiting to accept...\n");
		connection_t * connection;
		pthread_t thread;
		connection = (connection_t *)malloc(sizeof(connection_t));
		connection->sock = accept(sock, &connection->address, &connection->addr_len);
		printf("Accept\n");
		if (connection->sock <= 0)
		{
			free(connection);
		}
		else
		{
	pthread_create(&thread, 0, process, (void *)connection);
	pthread_detach(thread);
		}
	}while(1);

	close(sock);
	SSL_CTX_free(ctx);
	return 0;
}

